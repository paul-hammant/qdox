package com.example.lambda;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
