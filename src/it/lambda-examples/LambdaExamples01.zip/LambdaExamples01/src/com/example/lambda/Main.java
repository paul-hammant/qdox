package com.example.lambda;

/**
 * @author mikew
 */
public class Main {

  public static void main(String[] args) {
    
    RunnableTest.main(args);
    ComparatorTest.main(args);
    ListenerTest.main(args);
  }
}
